import { PDFDocument, StandardFonts, rgb } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.mjs';

async function testMilestone1() {
  console.log('--- TEST 1: Generate PDF locally via pdf-lib ---');
  const pdfDoc = await PDFDocument.create();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  
  for (let i = 1; i <= 3; i++) {
    const page = pdfDoc.addPage([595.28, 841.89]);
    page.drawText(`PDF Studio Milestone 1 Test Page ${i}`, {
      x: 50,
      y: 750,
      size: 18,
      font,
      color: rgb(0.1, 0.1, 0.1)
    });
  }

  const pdfBytes = await pdfDoc.save();
  console.log(`✓ PDF successfully generated: ${pdfBytes.byteLength} bytes, 3 pages.`);

  console.log('\n--- TEST 2: Parse PDF using PDF.js locally ---');
  const loadingTask = pdfjsLib.getDocument({
    data: pdfBytes,
    disableFontFace: true
  });
  
  const doc = await loadingTask.promise;
  console.log(`✓ PDF.js successfully parsed document. numPages = ${doc.numPages}`);
  
  if (doc.numPages !== 3) {
    throw new Error(`Expected 3 pages, got ${doc.numPages}`);
  }

  const page1 = await doc.getPage(1);
  const viewport = page1.getViewport({ scale: 1.0 });
  console.log(`✓ Page 1 dimensions: ${viewport.width} x ${viewport.height} pt`);

  const textContent = await page1.getTextContent();
  const textStrings = textContent.items.map(item => item.str).join(' ');
  console.log(`✓ Extracted text content: "${textStrings}"`);

  if (!textStrings.includes('PDF Studio Milestone 1 Test Page 1')) {
    throw new Error('Extracted text does not match generated text!');
  }

  console.log('\n--- ALL CORE TESTS PASSED! ---');
}

testMilestone1().catch(err => {
  console.error('Test failed:', err);
  process.exit(1);
});

